// Game state variables
let board = [];
let solution = [];
let selectedCell = null;
let timer = null;
let seconds = 0;
let minutes = 0;
let gameActive = false;
let difficulty = 'easy';

// DOM elements
const boardElement = document.getElementById('board');
const minutesElement = document.getElementById('minutes');
const secondsElement = document.getElementById('seconds');
const difficultySelect = document.getElementById('difficulty-select');
const newGameBtn = document.getElementById('new-game-btn');
const hintBtn = document.getElementById('hint-btn');
const solveBtn = document.getElementById('solve-btn');
const messageElement = document.getElementById('message');
const numberButtons = document.querySelectorAll('.number');

// Initialize the game
function initGame() {
    createBoard();
    difficultySelect.addEventListener('change', () => {
        difficulty = difficultySelect.value;
    });
    
    newGameBtn.addEventListener('click', startNewGame);
    hintBtn.addEventListener('click', giveHint);
    solveBtn.addEventListener('click', solveGame);
    
    numberButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (selectedCell && gameActive) {
                const number = parseInt(button.dataset.number);
                enterNumber(number);
            }
        });
    });
    
    startNewGame();
}

// Create the board UI
function createBoard() {
    boardElement.innerHTML = '';
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = i;
            cell.dataset.col = j;
            
            cell.addEventListener('click', () => {
                if (gameActive && !cell.classList.contains('fixed')) {
                    // Deselect previously selected cell
                    if (selectedCell) {
                        selectedCell.classList.remove('selected');
                    }
                    
                    // Select new cell
                    cell.classList.add('selected');
                    selectedCell = cell;
                }
            });
            
            boardElement.appendChild(cell);
        }
    }
}

// Start a new game
function startNewGame() {
    resetTimer();
    startTimer();
    gameActive = true;
    messageElement.textContent = '';
    
    // Generate a new puzzle
    generatePuzzle();
    
    // Update the UI
    updateBoardUI();
}

// Generate a Sudoku puzzle
function generatePuzzle() {
    // First, generate a solved board
    solution = generateSolvedBoard();
    
    // Create a copy of the solution
    board = JSON.parse(JSON.stringify(solution));
    
    // Remove numbers based on difficulty
    let cellsToRemove;
    switch (difficulty) {
        case 'easy':
            cellsToRemove = 40; // 41 clues remain
            break;
        case 'medium':
            cellsToRemove = 50; // 31 clues remain
            break;
        case 'hard':
            cellsToRemove = 60; // 21 clues remain
            break;
        default:
            cellsToRemove = 40;
    }
    
    // Randomly remove numbers
    let removed = 0;
    while (removed < cellsToRemove) {
        const row = Math.floor(Math.random() * 9);
        const col = Math.floor(Math.random() * 9);
        
        if (board[row][col] !== 0) {
            board[row][col] = 0;
            removed++;
        }
    }
}

// Generate a solved Sudoku board
function generateSolvedBoard() {
    // Create an empty 9x9 board
    const board = Array(9).fill().map(() => Array(9).fill(0));
    
    // Fill the board using backtracking
    solveSudoku(board);
    return board;
}

// Solve the Sudoku using backtracking algorithm
function solveSudoku(board) {
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            // Find an empty cell
            if (board[row][col] === 0) {
                // Try placing numbers 1-9
                const numbers = shuffleArray([1, 2, 3, 4, 5, 6, 7, 8, 9]);
                for (const num of numbers) {
                    if (isValidPlacement(board, row, col, num)) {
                        board[row][col] = num;
                        
                        // Recursively try to solve the rest of the board
                        if (solveSudoku(board)) {
                            return true;
                        }
                        
                        // If we couldn't solve it, backtrack
                        board[row][col] = 0;
                    }
                }
                return false; // No valid number found
            }
        }
    }
    return true; // Board is solved
}

// Check if a number can be placed at a position
function isValidPlacement(board, row, col, num) {
    // Check row
    for (let i = 0; i < 9; i++) {
        if (board[row][i] === num) {
            return false;
        }
    }
    
    // Check column
    for (let i = 0; i < 9; i++) {
        if (board[i][col] === num) {
            return false;
        }
    }
    
    // Check 3x3 box
    const boxRow = Math.floor(row / 3) * 3;
    const boxCol = Math.floor(col / 3) * 3;
    
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[boxRow + i][boxCol + j] === num) {
                return false;
            }
        }
    }
    
    return true;
}

// Shuffle array (Fisher-Yates algorithm)
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Update the board UI based on the current board state
function updateBoardUI() {
    const cells = document.querySelectorAll('.cell');
    
    cells.forEach(cell => {
        const row = parseInt(cell.dataset.row);
        const col = parseInt(cell.dataset.col);
        const value = board[row][col];
        
        cell.textContent = value !== 0 ? value : '';
        
        // Reset classes
        cell.classList.remove('fixed', 'error', 'hint');
        
        // Mark original cells as fixed
        if (value !== 0 && board[row][col] === solution[row][col]) {
            cell.classList.add('fixed');
        }
    });
    
    // Deselect any selected cell
    if (selectedCell) {
        selectedCell.classList.remove('selected');
        selectedCell = null;
    }
}

// Enter a number in the selected cell
function enterNumber(number) {
    if (!selectedCell || !gameActive) return;
    
    const row = parseInt(selectedCell.dataset.row);
    const col = parseInt(selectedCell.dataset.col);
    
    // Erase if number is 0
    if (number === 0) {
        board[row][col] = 0;
        selectedCell.textContent = '';
        selectedCell.classList.remove('error');
        return;
    }
    
    // Update the board
    board[row][col] = number;
    selectedCell.textContent = number;
    
    // Check if the number is correct
    if (number !== solution[row][col]) {
        selectedCell.classList.add('error');
    } else {
        selectedCell.classList.remove('error');
    }
    
    // Check if the game is won
    if (checkWin()) {
        gameWon();
    }
}

// Check if the game is won
function checkWin() {
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (board[i][j] !== solution[i][j]) {
                return false;
            }
        }
    }
    return true;
}

// Handle game win
function gameWon() {
    gameActive = false;
    stopTimer();
    messageElement.textContent = 'Congratulations! You solved the puzzle!';
}

// Give a hint
function giveHint() {
    if (!gameActive) return;
    
    // Find a random cell that's not correct
    const emptyCells = [];
    
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (board[i][j] !== solution[i][j]) {
                emptyCells.push({ row: i, col: j });
            }
        }
    }
    
    if (emptyCells.length === 0) return;
    
    // Select a random empty cell
    const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    const { row, col } = randomCell;
    
    // Update the board
    board[row][col] = solution[row][col];
    
    // Update the UI
    const cells = document.querySelectorAll('.cell');
    cells.forEach(cell => {
        const cellRow = parseInt(cell.dataset.row);
        const cellCol = parseInt(cell.dataset.col);
        
        if (cellRow === row && cellCol === col) {
            cell.textContent = solution[row][col];
            cell.classList.add('hint');
        }
    });
    
    // Check if the game is won
    if (checkWin()) {
        gameWon();
    }
}

// Solve the game
function solveGame() {
    if (!gameActive) return;
    
    board = JSON.parse(JSON.stringify(solution));
    updateBoardUI();
    gameWon();
}

// Timer functions
function startTimer() {
    seconds = 0;
    minutes = 0;
    updateTimerDisplay();
    
    timer = setInterval(() => {
        seconds++;
        if (seconds === 60) {
            seconds = 0;
            minutes++;
        }
        updateTimerDisplay();
    }, 1000);
}

function stopTimer() {
    clearInterval(timer);
}

function resetTimer() {
    stopTimer();
    seconds = 0;
    minutes = 0;
    updateTimerDisplay();
}

function updateTimerDisplay() {
    minutesElement.textContent = minutes.toString().padStart(2, '0');
    secondsElement.textContent = seconds.toString().padStart(2, '0');
}

// Initialize the game when the page loads
window.addEventListener('load', initGame);