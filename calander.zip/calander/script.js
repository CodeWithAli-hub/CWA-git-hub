document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const currentYearElement = document.getElementById('current-year');
    const yearInput = document.getElementById('year-input');
    const goBtn = document.getElementById('go-btn');
    const prevYearBtn = document.getElementById('prev-year');
    const nextYearBtn = document.getElementById('next-year');
    const monthsContainer = document.getElementById('months-container');
    
    // Current date information
    const today = new Date();
    let currentYear = today.getFullYear();
    
    // Month names
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    
    // Day names
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    // Color themes for different years and months
    function getYearColor(year) {
        // Generate a color based on the year
        const hue = (year % 360);
        const saturation = 70;
        const lightness = 50;
        
        return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
    }
    
    function getMonthColor(year, month) {
        // Generate a unique color for each month within a year
        // We'll use the year's base hue and adjust it for each month
        const baseHue = (year % 360);
        // Distribute the 12 months across a 30-degree range from the base hue
        const hue = (baseHue + (month * 30)) % 360;
        const saturation = 70;
        const lightness = 50;
        
        return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
    }
    
    // Apply year color to UI elements
    function applyYearColor(year) {
        const color = getYearColor(year);
        const lighterColor = `hsl(${year % 360}, 70%, 60%)`;
        const darkerColor = `hsl(${year % 360}, 70%, 40%)`;
        
        document.body.style.backgroundColor = `hsl(${year % 360}, 30%, 95%)`;
        
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            button.style.backgroundColor = color;
            button.addEventListener('mouseenter', () => {
                button.style.backgroundColor = darkerColor;
            });
            button.addEventListener('mouseleave', () => {
                button.style.backgroundColor = color;
            });
        });
    }
    
    // Generate calendar for a specific month and year
    function generateMonthCalendar(month, year) {
        const monthDiv = document.createElement('div');
        monthDiv.className = 'month';
        
        // Get month-specific color
        const monthColor = getMonthColor(year, month);
        
        // Month header
        const monthHeader = document.createElement('div');
        monthHeader.className = 'month-header';
        monthHeader.textContent = monthNames[month];
        monthHeader.style.backgroundColor = monthColor;
        monthDiv.appendChild(monthHeader);
        
        // Days grid
        const daysGrid = document.createElement('div');
        daysGrid.className = 'days-grid';
        
        // Add day names (Sun, Mon, etc.)
        dayNames.forEach(day => {
            const dayNameDiv = document.createElement('div');
            dayNameDiv.className = 'day-name';
            dayNameDiv.textContent = day;
            daysGrid.appendChild(dayNameDiv);
        });
        
        // Get first day of the month and total days
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const totalDays = lastDay.getDate();
        const startingDay = firstDay.getDay(); // 0 = Sunday, 1 = Monday, etc.
        
        // Add empty cells for days before the first day of the month
        for (let i = 0; i < startingDay; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'day other-month';
            daysGrid.appendChild(emptyDay);
        }
        
        // Add days of the month
        for (let day = 1; day <= totalDays; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.className = 'day';
            dayDiv.textContent = day;
            
            // Highlight today
            if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                dayDiv.classList.add('today');
                dayDiv.style.backgroundColor = monthColor;
            }
            
            daysGrid.appendChild(dayDiv);
        }
        
        monthDiv.appendChild(daysGrid);
        return monthDiv;
    }
    
    // Generate full year calendar
    function generateCalendar(year) {
        // Clear previous calendar
        monthsContainer.innerHTML = '';
        monthsContainer.classList.add('year-animation');
        
        // Update current year display
        currentYearElement.textContent = year;
        
        // Generate each month
        for (let month = 0; month < 12; month++) {
            const monthCalendar = generateMonthCalendar(month, year);
            monthsContainer.appendChild(monthCalendar);
        }
        
        // Apply color theme based on year
        applyYearColor(year);
        
        // Remove animation class after animation completes
        setTimeout(() => {
            monthsContainer.classList.remove('year-animation');
        }, 500);
    }
    
    // Initialize calendar with current year
    generateCalendar(currentYear);
    
    // Event listeners for navigation
    prevYearBtn.addEventListener('click', () => {
        if (currentYear > 1900) {
            currentYear--;
            generateCalendar(currentYear);
        }
    });
    
    nextYearBtn.addEventListener('click', () => {
        if (currentYear < 2500) {
            currentYear++;
            generateCalendar(currentYear);
        }
    });
    
    // Go to specific year
    goBtn.addEventListener('click', () => {
        const inputYear = parseInt(yearInput.value);
        if (inputYear >= 1900 && inputYear <= 2500) {
            currentYear = inputYear;
            generateCalendar(currentYear);
            yearInput.value = '';
        } else {
            alert('Please enter a year between 1900 and 2500');
        }
    });
    
    // Allow pressing Enter in the input field
    yearInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            goBtn.click();
        }
    });
});