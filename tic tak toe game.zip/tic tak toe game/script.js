document.addEventListener('DOMContentLoaded', () => {
    // Game elements
    const cells = document.querySelectorAll('.cell');
    const gameStatus = document.querySelector('.game-status');
    const resetButton = document.getElementById('reset-game');
    const newGameButton = document.getElementById('new-game');
    const playerVsPlayerButton = document.getElementById('player-vs-player');
    const playerVsCpuButton = document.getElementById('player-vs-cpu');
    const playerX = document.querySelector('.player-x');
    const playerO = document.querySelector('.player-o');
    const playerXScore = playerX.querySelector('.player-score');
    const playerOScore = playerO.querySelector('.player-score');
    const winningLine = document.getElementById('winning-line');
    
    // Audio elements
    const placeSound = document.getElementById('place-sound');
    const winSound = document.getElementById('win-sound');
    const drawSound = document.getElementById('draw-sound');
    
    // Game state
    let gameActive = true;
    let currentPlayer = 'x';
    let gameState = ['', '', '', '', '', '', '', '', ''];
    let isCpuMode = false;
    let scores = { x: 0, o: 0 };
    
    // Winning combinations
    const winningConditions = [
        [0, 1, 2], // top row
        [3, 4, 5], // middle row
        [6, 7, 8], // bottom row
        [0, 3, 6], // left column
        [1, 4, 7], // middle column
        [2, 5, 8], // right column
        [0, 4, 8], // diagonal top-left to bottom-right
        [2, 4, 6]  // diagonal top-right to bottom-left
    ];
    
    // Messages
    const winMessage = () => `Team ${currentPlayer.toUpperCase()} wins!`;
    const drawMessage = () => `Game ended in a draw!`;
    const currentPlayerTurn = () => `Team ${currentPlayer.toUpperCase()}'s turn`;
    
    // Initialize game
    updateGameStatus(currentPlayerTurn());
    
    // Event listeners
    cells.forEach(cell => {
        cell.addEventListener('click', cellClicked);
    });
    
    resetButton.addEventListener('click', resetGame);
    newGameButton.addEventListener('click', newGame);
    playerVsPlayerButton.addEventListener('click', () => setGameMode(false));
    playerVsCpuButton.addEventListener('click', () => setGameMode(true));
    
    // Functions
    function cellClicked(e) {
        const clickedCell = e.target;
        const clickedCellIndex = parseInt(clickedCell.getAttribute('data-index'));
        
        if (gameState[clickedCellIndex] !== '' || !gameActive) {
            return;
        }
        
        cellPlayed(clickedCell, clickedCellIndex);
        checkResult();
        
        if (gameActive && isCpuMode && currentPlayer === 'o') {
            setTimeout(cpuMove, 700);
        }
    }
    
    function cellPlayed(clickedCell, clickedCellIndex) {
        gameState[clickedCellIndex] = currentPlayer;
        clickedCell.classList.add(currentPlayer);
        clickedCell.classList.add('placed');
        playSound(placeSound);
    }
    
    function checkResult() {
        let roundWon = false;
        let winningCombo = null;
        
        for (let i = 0; i < winningConditions.length; i++) {
            const [a, b, c] = winningConditions[i];
            const condition = gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c];
            
            if (condition) {
                roundWon = true;
                winningCombo = winningConditions[i];
                break;
            }
        }
        
        if (roundWon) {
            updateGameStatus(winMessage());
            gameActive = false;
            scores[currentPlayer]++;
            updateScores();
            highlightWinningCells(winningCombo);
            playSound(winSound);
            return;
        }
        
        const roundDraw = !gameState.includes('');
        if (roundDraw) {
            updateGameStatus(drawMessage());
            gameActive = false;
            playSound(drawSound);
            return;
        }
        
        changePlayer();
    }
    
    function changePlayer() {
        currentPlayer = currentPlayer === 'x' ? 'o' : 'x';
        updateGameStatus(currentPlayerTurn());
        updateActivePlayerIndicator();
    }
    
    function updateGameStatus(message) {
        gameStatus.textContent = message;
    }
    
    function resetGame() {
        gameActive = true;
        currentPlayer = 'x';
        gameState = ['', '', '', '', '', '', '', '', ''];
        updateGameStatus(currentPlayerTurn());
        updateActivePlayerIndicator();
        cells.forEach(cell => {
            cell.classList.remove('x', 'o', 'placed', 'win-animation');
        });
        winningLine.style.display = 'none';
        
        if (isCpuMode && currentPlayer === 'o') {
            setTimeout(cpuMove, 700);
        }
    }
    
    function newGame() {
        scores = { x: 0, o: 0 };
        updateScores();
        resetGame();
    }
    
    function updateScores() {
        playerXScore.textContent = scores.x;
        playerOScore.textContent = scores.o;
    }
    
    function updateActivePlayerIndicator() {
        if (currentPlayer === 'x') {
            playerX.classList.add('active');
            playerO.classList.remove('active');
        } else {
            playerO.classList.add('active');
            playerX.classList.remove('active');
        }
    }
    
    function setGameMode(cpuMode) {
        isCpuMode = cpuMode;
        if (cpuMode) {
            playerVsCpuButton.classList.add('active');
            playerVsPlayerButton.classList.remove('active');
            playerO.querySelector('.player-name').textContent = 'CPU (O)';
        } else {
            playerVsPlayerButton.classList.add('active');
            playerVsCpuButton.classList.remove('active');
            playerO.querySelector('.player-name').textContent = 'Team B (O)';
        }
        newGame();
    }
    
    function cpuMove() {
        if (!gameActive) return;
        
        // Try to find winning move
        const winMove = findBestMove('o');
        if (winMove !== -1) {
            makeMove(winMove);
            return;
        }
        
        // Try to block player's winning move
        const blockMove = findBestMove('x');
        if (blockMove !== -1) {
            makeMove(blockMove);
            return;
        }
        
        // Take center if available
        if (gameState[4] === '') {
            makeMove(4);
            return;
        }
        
        // Take a random available cell
        const availableCells = gameState
            .map((cell, index) => cell === '' ? index : null)
            .filter(cell => cell !== null);
            
        if (availableCells.length > 0) {
            const randomIndex = Math.floor(Math.random() * availableCells.length);
            makeMove(availableCells[randomIndex]);
        }
    }
    
    function findBestMove(player) {
        for (let i = 0; i < winningConditions.length; i++) {
            const [a, b, c] = winningConditions[i];
            // Check if two cells are filled by the player and one is empty
            if (gameState[a] === player && gameState[b] === player && gameState[c] === '') {
                return c;
            }
            if (gameState[a] === player && gameState[c] === player && gameState[b] === '') {
                return b;
            }
            if (gameState[b] === player && gameState[c] === player && gameState[a] === '') {
                return a;
            }
        }
        return -1;
    }
    
    function makeMove(index) {
        const cell = document.querySelector(`.cell[data-index="${index}"]`);
        cellPlayed(cell, index);
        checkResult();
    }
    
    function highlightWinningCells(combo) {
        combo.forEach(index => {
            document.querySelector(`.cell[data-index="${index}"]`).classList.add('win-animation');
        });
        
        // Draw winning line
        drawWinningLine(combo);
    }
    
    function drawWinningLine(combo) {
        const [a, b, c] = combo;
        const cellA = document.querySelector(`.cell[data-index="${a}"]`);
        const cellC = document.querySelector(`.cell[data-index="${c}"]`);
        
        const rect = document.querySelector('.game-board').getBoundingClientRect();
        const cellARect = cellA.getBoundingClientRect();
        const cellCRect = cellC.getBoundingClientRect();
        
        const startX = cellARect.left + cellARect.width / 2 - rect.left;
        const startY = cellARect.top + cellARect.height / 2 - rect.top;
        const endX = cellCRect.left + cellCRect.width / 2 - rect.left;
        const endY = cellCRect.top + cellCRect.height / 2 - rect.top;
        
        const length = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
        const angle = Math.atan2(endY - startY, endX - startX) * 180 / Math.PI;
        
        winningLine.style.width = `${length}px`;
        winningLine.style.height = '10px';
        winningLine.style.left = `${startX}px`;
        winningLine.style.top = `${startY}px`;
        winningLine.style.transformOrigin = '0 50%';
        winningLine.style.transform = `rotate(${angle}deg)`;
        winningLine.style.display = 'block';
    }
    
    function playSound(sound) {
        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(e => console.log("Audio play failed:", e));
        }
    }
});