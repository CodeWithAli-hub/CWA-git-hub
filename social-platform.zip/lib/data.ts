// This file would contain data fetching functions
// In a real app, these would query your database

import type { User } from "./types"

export async function getFeed(userId: string) {
  // In a real app, this would fetch posts from your database
  console.log("Getting feed for user:", userId)

  // Simulate a delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Return mock posts
  return {
    posts: [
      {
        id: "post_1",
        content: "This is a sample post. In a real app, this would be fetched from your database.",
        mediaUrl: null,
        mediaType: null,
        createdAt: new Date().toISOString(),
        author: {
          id: "user_2",
          username: "jane_doe",
          name: "Jane Doe",
          image: null,
        },
        likeCount: 5,
        isLiked: false,
        isAuthor: false,
        comments: [],
      },
      {
        id: "post_2",
        content: "Another sample post. This one is from the current user.",
        mediaUrl: null,
        mediaType: null,
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        author: {
          id: "user_1",
          username: "demo_user",
          name: "Demo User",
          image: null,
        },
        likeCount: 2,
        isLiked: true,
        isAuthor: true,
        comments: [
          {
            id: "comment_1",
            content: "This is a sample comment",
            createdAt: new Date(Date.now() - 1800000).toISOString(),
            author: {
              id: "user_2",
              username: "jane_doe",
              name: "Jane Doe",
              image: null,
            },
          },
        ],
      },
    ],
    hasMore: false,
  }
}

export async function getUserWithFriendCount(userId: string) {
  // In a real app, this would fetch user data from your database
  console.log("Getting user with friend count:", userId)

  // Simulate a delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Return mock user data
  return {
    user: {
      id: userId,
      username: "demo_user",
      name: "Demo User",
      email: "user@example.com",
      image: null,
      bio: null,
      postsToday: 1,
      postCount: 5,
      friendCount: 3,
    },
    friendCount: 3,
  }
}

export async function getUserByUsername(username: string): Promise<User | null> {
  // In a real app, this would fetch user data from your database
  console.log("Getting user by username:", username)

  // Simulate a delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Return mock user data
  if (username === "demo_user") {
    return {
      id: "user_1",
      username: "demo_user",
      name: "Demo User",
      email: "user@example.com",
      image: null,
      bio: "This is a sample bio",
      postsToday: 1,
      postCount: 5,
      friendCount: 3,
    }
  }

  return null
}

export async function getUserPosts(userId: string) {
  // In a real app, this would fetch posts from your database
  console.log("Getting posts for user:", userId)

  // Simulate a delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Return mock posts
  return {
    posts: [
      {
        id: "post_2",
        content: "This is a sample post from the user profile.",
        mediaUrl: null,
        mediaType: null,
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        author: {
          id: userId,
          username: "demo_user",
          name: "Demo User",
          image: null,
        },
        likeCount: 2,
        isLiked: false,
        isAuthor: userId === "user_1",
        comments: [],
      },
    ],
  }
}

export async function getFriendStatus(currentUserId: string, targetUserId: string) {
  // In a real app, this would check the friendship status in your database
  console.log("Getting friend status:", { currentUserId, targetUserId })

  // Simulate a delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Return mock status
  return "none" as "none" | "requested" | "pending" | "friends"
}
