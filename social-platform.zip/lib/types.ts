export interface User {
  id: string
  username: string
  name: string | null
  email: string
  image: string | null
  bio: string | null
  postsToday: number
  postCount: number
  friendCount: number
}

export interface Post {
  id: string
  content: string | null
  mediaUrl: string | null
  mediaType: "image" | "video" | null
  createdAt: string
  author: {
    id: string
    username: string
    name: string | null
    image: string | null
  }
  likeCount: number
  isLiked: boolean
  isAuthor: boolean
  comments: Comment[]
}

export interface Comment {
  id: string
  content: string
  createdAt: string
  author: {
    id: string
    username: string
    name: string | null
    image: string | null
  }
}

export interface FriendRequest {
  id: string
  senderId: string
  receiverId: string
  status: "pending" | "accepted" | "rejected"
  createdAt: string
}
