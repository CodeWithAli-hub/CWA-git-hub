import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { getFeed, getUserWithFriendCount } from "@/lib/data"
import PostList from "@/components/post-list"
import CreatePostButton from "@/components/create-post-button"
import FriendSuggestions from "@/components/friend-suggestions"

export default async function FeedPage() {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  const userId = session.user.id
  const { posts, hasMore } = await getFeed(userId)
  const { user, friendCount } = await getUserWithFriendCount(userId)

  // Determine if user can post based on friend count
  const canPost = friendCount > 0
  const postsRemaining = calculatePostsRemaining(friendCount, user.postsToday)

  return (
    <div className="container max-w-4xl py-6 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Your Feed</h1>
        {canPost && postsRemaining > 0 ? (
          <CreatePostButton postsRemaining={postsRemaining} />
        ) : (
          <div className="text-sm text-gray-500">
            {friendCount === 0 ? "You need at least one friend to post" : "You've used all your posts for today"}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <PostList posts={posts} hasMore={hasMore} />
        </div>
        <div className="space-y-6">
          <div className="p-4 border rounded-lg">
            <h2 className="mb-2 text-lg font-semibold">Your Posting Limit</h2>
            <p className="text-sm text-gray-500">
              {friendCount === 0
                ? "You need at least one friend to post"
                : friendCount < 10
                  ? `You can post ${friendCount} time${friendCount > 1 ? "s" : ""} per day`
                  : "You can post multiple times per day"}
            </p>
            <p className="mt-2 text-sm">
              <span className="font-medium">Friends:</span> {friendCount}
            </p>
            {canPost && (
              <p className="mt-1 text-sm">
                <span className="font-medium">Posts remaining today:</span> {postsRemaining}
              </p>
            )}
          </div>
          <FriendSuggestions />
        </div>
      </div>
    </div>
  )
}

function calculatePostsRemaining(friendCount: number, postsToday: number): number {
  if (friendCount === 0) return 0
  if (friendCount < 10) return Math.max(0, friendCount - postsToday)
  // For 10+ friends, let's say they get 15 posts per day
  return Math.max(0, 15 - postsToday)
}
