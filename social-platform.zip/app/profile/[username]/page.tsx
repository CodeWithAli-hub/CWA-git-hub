import { notFound } from "next/navigation"
import { auth } from "@/lib/auth"
import { getUserByUsername, getUserPosts, getFriendStatus } from "@/lib/data"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PostList from "@/components/post-list"
import FriendButton from "@/components/friend-button"

interface ProfilePageProps {
  params: {
    username: string
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const session = await auth()
  const { username } = params

  const profile = await getUserByUsername(username)

  if (!profile) {
    notFound()
  }

  const { posts } = await getUserPosts(profile.id)
  const isCurrentUser = session?.user.id === profile.id

  let friendStatus = null
  if (session && !isCurrentUser) {
    friendStatus = await getFriendStatus(session.user.id, profile.id)
  }

  return (
    <div className="container max-w-4xl py-6">
      <Card className="p-6 mb-6">
        <div className="flex flex-col items-center gap-4 md:flex-row md:items-start">
          <Avatar className="w-24 h-24 md:w-32 md:h-32">
            <AvatarImage src={profile.image || "/placeholder-user.jpg"} alt={profile.name || profile.username} />
            <AvatarFallback>{profile.username.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>

          <div className="flex-1 text-center md:text-left">
            <h1 className="text-2xl font-bold">{profile.name || profile.username}</h1>
            <p className="text-gray-500">@{profile.username}</p>

            <div className="flex flex-wrap justify-center gap-4 mt-4 md:justify-start">
              <div>
                <span className="font-bold">{profile.postCount}</span>
                <span className="text-gray-500 ml-1">Posts</span>
              </div>
              <div>
                <span className="font-bold">{profile.friendCount}</span>
                <span className="text-gray-500 ml-1">Friends</span>
              </div>
            </div>

            {profile.bio && <p className="mt-4">{profile.bio}</p>}
          </div>

          <div className="mt-4 md:mt-0">
            {isCurrentUser ? (
              <Button variant="outline" asChild>
                <a href="/profile/edit">Edit Profile</a>
              </Button>
            ) : (
              <FriendButton userId={profile.id} initialStatus={friendStatus} />
            )}
          </div>
        </div>
      </Card>

      <Tabs defaultValue="posts">
        <TabsList className="mb-6">
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="friends">Friends</TabsTrigger>
        </TabsList>

        <TabsContent value="posts">
          {posts.length > 0 ? (
            <PostList posts={posts} hasMore={false} />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No posts yet</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="friends">
          {/* Friend list component would go here */}
          <div className="text-center py-12">
            <p className="text-gray-500">Friend list coming soon</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
