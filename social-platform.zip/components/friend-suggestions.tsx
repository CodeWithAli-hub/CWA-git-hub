"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { UserPlus } from "lucide-react"
import { getFriendSuggestions, sendFriendRequest } from "@/lib/actions"

interface User {
  id: string
  username: string
  name: string | null
  image: string | null
}

export default function FriendSuggestions() {
  const [suggestions, setSuggestions] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [pendingRequests, setPendingRequests] = useState<Set<string>>(new Set())

  useEffect(() => {
    const loadSuggestions = async () => {
      try {
        const users = await getFriendSuggestions()
        setSuggestions(users)
      } catch (error) {
        console.error("Failed to load friend suggestions:", error)
      } finally {
        setLoading(false)
      }
    }

    loadSuggestions()
  }, [])

  const handleSendRequest = async (userId: string) => {
    if (pendingRequests.has(userId)) return

    setPendingRequests((prev) => new Set(prev).add(userId))

    try {
      await sendFriendRequest(userId)
      // Remove from suggestions
      setSuggestions((prev) => prev.filter((user) => user.id !== userId))
    } catch (error) {
      console.error("Failed to send friend request:", error)
      setPendingRequests((prev) => {
        const updated = new Set(prev)
        updated.delete(userId)
        return updated
      })
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>People you may know</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500">Loading suggestions...</p>
        </CardContent>
      </Card>
    )
  }

  if (suggestions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>People you may know</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500">No suggestions available</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>People you may know</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {suggestions.map((user) => (
            <div key={user.id} className="flex items-center justify-between">
              <Link href={`/profile/${user.username}`} className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.image || "/placeholder-user.jpg"} alt={user.username} />
                  <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{user.name || user.username}</p>
                  <p className="text-xs text-gray-500">@{user.username}</p>
                </div>
              </Link>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleSendRequest(user.id)}
                disabled={pendingRequests.has(user.id)}
              >
                <UserPlus className="h-4 w-4 mr-1" />
                {pendingRequests.has(user.id) ? "Sent" : "Add"}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
