import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"

interface CreatePostButtonProps {
  postsRemaining: number
}

export default function CreatePostButton({ postsRemaining }: CreatePostButtonProps) {
  return (
    <Button asChild>
      <Link href="/create-post" className="flex items-center gap-2">
        <PlusCircle className="w-4 h-4" />
        Create Post
        {postsRemaining > 0 && (
          <span className="text-xs bg-primary-foreground text-primary px-2 py-0.5 rounded-full">
            {postsRemaining} left today
          </span>
        )}
      </Link>
    </Button>
  )
}
