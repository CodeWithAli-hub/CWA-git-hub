"use client"

import { useState } from "react"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { Heart, MessageCircle, Share2, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { Post } from "@/lib/types"
import { likePost, addComment, deletePost } from "@/lib/actions"

interface PostCardProps {
  post: Post
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(post.isLiked)
  const [likeCount, setLikeCount] = useState(post.likeCount)
  const [showComments, setShowComments] = useState(false)
  const [commentText, setCommentText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [comments, setComments] = useState(post.comments || [])

  const handleLike = async () => {
    try {
      await likePost(post.id, !liked)
      setLiked(!liked)
      setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
    } catch (error) {
      console.error("Failed to like post:", error)
    }
  }

  const handleComment = async () => {
    if (!commentText.trim() || isSubmitting) return

    setIsSubmitting(true)
    try {
      const newComment = await addComment(post.id, commentText)
      setComments([...comments, newComment])
      setCommentText("")
    } catch (error) {
      console.error("Failed to add comment:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this post?")) return

    try {
      await deletePost(post.id)
      // Refresh the page to show updated feed
      window.location.reload()
    } catch (error) {
      console.error("Failed to delete post:", error)
    }
  }

  return (
    <Card>
      <CardHeader className="p-4 pb-0">
        <div className="flex justify-between items-center">
          <Link href={`/profile/${post.author.username}`} className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={post.author.image || "/placeholder-user.jpg"} alt={post.author.username} />
              <AvatarFallback>{post.author.username.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{post.author.name || post.author.username}</p>
              <p className="text-xs text-gray-500">
                {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
              </p>
            </div>
          </Link>

          {post.isAuthor && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleDelete} className="text-red-500">
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </CardHeader>

      <CardContent className="p-4">
        {post.content && <p className="mb-4">{post.content}</p>}

        {post.mediaUrl && (
          <div className="rounded-md overflow-hidden">
            {post.mediaType === "image" ? (
              <img
                src={post.mediaUrl || "/placeholder.svg"}
                alt="Post media"
                className="w-full object-cover max-h-[500px]"
              />
            ) : (
              <video src={post.mediaUrl} controls className="w-full max-h-[500px]" />
            )}
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0 flex flex-col">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="flex items-center gap-1 h-8" onClick={handleLike}>
              <Heart className={`h-4 w-4 ${liked ? "fill-red-500 text-red-500" : ""}`} />
              <span>{likeCount}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="flex items-center gap-1 h-8"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageCircle className="h-4 w-4" />
              <span>{comments.length}</span>
            </Button>
          </div>

          <Button variant="ghost" size="sm" className="h-8">
            <Share2 className="h-4 w-4 mr-1" />
            Share
          </Button>
        </div>

        {showComments && (
          <div className="mt-4 w-full space-y-4">
            {comments.length > 0 && (
              <div className="space-y-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage
                        src={comment.author.image || "/placeholder-user.jpg"}
                        alt={comment.author.username}
                      />
                      <AvatarFallback>{comment.author.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded-md">
                        <Link href={`/profile/${comment.author.username}`} className="font-medium text-sm">
                          {comment.author.name || comment.author.username}
                        </Link>
                        <p className="text-sm">{comment.content}</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Textarea
                placeholder="Add a comment..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="min-h-[60px]"
              />
              <Button onClick={handleComment} disabled={!commentText.trim() || isSubmitting} className="self-end">
                Post
              </Button>
            </div>
          </div>
        )}
      </CardFooter>
    </Card>
  )
}
