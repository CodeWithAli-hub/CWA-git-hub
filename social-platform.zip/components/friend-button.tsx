"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { UserPlus, UserCheck, UserX } from "lucide-react"
import { sendFriendRequest, acceptFriendRequest, removeFriend } from "@/lib/actions"

interface FriendButtonProps {
  userId: string
  initialStatus: "none" | "requested" | "pending" | "friends" | null
}

export default function FriendButton({ userId, initialStatus }: FriendButtonProps) {
  const [status, setStatus] = useState(initialStatus)
  const [isLoading, setIsLoading] = useState(false)

  const handleAction = async () => {
    if (isLoading) return
    setIsLoading(true)

    try {
      switch (status) {
        case "none":
          await sendFriendRequest(userId)
          setStatus("requested")
          break
        case "pending":
          await acceptFriendRequest(userId)
          setStatus("friends")
          break
        case "friends":
        case "requested":
          await removeFriend(userId)
          setStatus("none")
          break
      }
    } catch (error) {
      console.error("Friend action failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (status === null) return null

  let buttonText = ""
  let icon = null
  let variant: "default" | "outline" | "destructive" = "default"

  switch (status) {
    case "none":
      buttonText = "Add Friend"
      icon = <UserPlus className="w-4 h-4 mr-2" />
      break
    case "requested":
      buttonText = "Cancel Request"
      icon = <UserX className="w-4 h-4 mr-2" />
      variant = "outline"
      break
    case "pending":
      buttonText = "Accept Request"
      icon = <UserCheck className="w-4 h-4 mr-2" />
      break
    case "friends":
      buttonText = "Friends"
      icon = <UserCheck className="w-4 h-4 mr-2" />
      variant = "outline"
      break
  }

  return (
    <Button variant={variant} onClick={handleAction} disabled={isLoading}>
      {icon}
      {isLoading ? "Loading..." : buttonText}
    </Button>
  )
}
