"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type { Post } from "@/lib/types"
import PostCard from "@/components/post-card"
import { Button } from "@/components/ui/button"
import { loadMorePosts } from "@/lib/actions"

interface PostListProps {
  posts: Post[]
  hasMore: boolean
}

export default function PostList({ posts: initialPosts, hasMore: initialHasMore }: PostListProps) {
  const router = useRouter()
  const [posts, setPosts] = useState(initialPosts)
  const [hasMore, setHasMore] = useState(initialHasMore)
  const [isLoading, setIsLoading] = useState(false)

  const handleLoadMore = async () => {
    if (!hasMore || isLoading) return

    setIsLoading(true)
    try {
      const lastPostId = posts[posts.length - 1].id
      const { posts: newPosts, hasMore: morePostsAvailable } = await loadMorePosts(lastPostId)

      setPosts([...posts, ...newPosts])
      setHasMore(morePostsAvailable)
    } catch (error) {
      console.error("Failed to load more posts:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {posts.length > 0 ? (
        <>
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}

          {hasMore && (
            <div className="flex justify-center">
              <Button variant="outline" onClick={handleLoadMore} disabled={isLoading}>
                {isLoading ? "Loading..." : "Load More"}
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500">No posts to show</p>
          <Button variant="outline" className="mt-4" onClick={() => router.refresh()}>
            Refresh
          </Button>
        </div>
      )}
    </div>
  )
}
