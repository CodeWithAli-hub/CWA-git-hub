document.addEventListener('DOMContentLoaded', function() {
    const calculateBtn = document.getElementById('calculate-btn');
    const birthdateInput = document.getElementById('birthdate');
    const resultDiv = document.getElementById('result');
    const yearsSpan = document.getElementById('years');
    const monthsSpan = document.getElementById('months');
    const daysSpan = document.getElementById('days');

    // Set max date to today
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    birthdateInput.max = `${yyyy}-${mm}-${dd}`;

    calculateBtn.addEventListener('click', calculateAge);

    function calculateAge() {
        // Get input value
        const birthdate = birthdateInput.value;
        
        if (!birthdate) {
            alert('Please enter your birth date');
            return;
        }

        // Parse dates
        const birthDate = new Date(birthdate);
        const currentDate = new Date();

        // Validate birth date
        if (birthDate > currentDate) {
            alert('Birth date cannot be in the future');
            return;
        }

        // Calculate age
        let years = currentDate.getFullYear() - birthDate.getFullYear();
        let months = currentDate.getMonth() - birthDate.getMonth();
        let days = currentDate.getDate() - birthDate.getDate();

        // Adjust for negative days
        if (days < 0) {
            months--;
            // Get the last day of the previous month
            const lastMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
            days += lastMonth.getDate();
        }

        // Adjust for negative months
        if (months < 0) {
            years--;
            months += 12;
        }

        // Display result
        yearsSpan.textContent = years;
        monthsSpan.textContent = months;
        daysSpan.textContent = days;
        
        // Show result with animation
        resultDiv.classList.add('active');
        
        // Add animation to age boxes
        animateCountUp('years', years);
        animateCountUp('months', months);
        animateCountUp('days', days);
    }

    function animateCountUp(elementId, targetValue) {
        const element = document.getElementById(elementId);
        element.textContent = '0';
        
        let currentValue = 0;
        const duration = 1000; // 1 second
        const stepTime = 50; // Update every 50ms
        const totalSteps = duration / stepTime;
        const increment = targetValue / totalSteps;
        
        const timer = setInterval(() => {
            currentValue += increment;
            if (currentValue >= targetValue) {
                clearInterval(timer);
                element.textContent = targetValue;
            } else {
                element.textContent = Math.floor(currentValue);
            }
        }, stepTime);
    }
});