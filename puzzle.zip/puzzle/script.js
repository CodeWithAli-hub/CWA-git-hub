class PuzzleGame {
    constructor() {
        this.board = Array.from({length: 16}, (_, i) => i);
        this.moves = 0;
        this.emptyIndex = 15;
        this.boardElement = document.getElementById('puzzleBoard');
        this.moveCounter = document.getElementById('moveCounter');
        this.shuffleButton = document.getElementById('shuffleButton');
        
        this.initialize();
    }

    initialize() {
        this.shuffle();
        this.render();
        this.addEventListeners();
    }

    shuffle() {
        for (let i = this.board.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.board[i], this.board[j]] = [this.board[j], this.board[i]];
            if (this.board[i] === 15) this.emptyIndex = i;
        }
    }

    render() {
        this.boardElement.innerHTML = '';
        this.board.forEach((num, index) => {
            const tile = document.createElement('div');
            tile.className = num === 15 ? 'tile empty' : 'tile';
            tile.dataset.index = index;
            
            if (num !== 15) {
                tile.textContent = num + 1;
                // Add dynamic background color based on number
                const hue = (num * 20) % 360;
                tile.style.background = `hsla(${hue}, 70%, 50%, 0.8)`;
            }
            
            this.boardElement.appendChild(tile);
        });
        this.moveCounter.textContent = `Moves: ${this.moves}`;
    }

    isMovable(index) {
        const row = Math.floor(index / 4);
        const emptyRow = Math.floor(this.emptyIndex / 4);
        const col = index % 4;
        const emptyCol = this.emptyIndex % 4;

        return (
            (Math.abs(row - emptyRow) === 1 && col === emptyCol) ||
            (Math.abs(col - emptyCol) === 1 && row === emptyRow)
        );
    }

    moveTile(index) {
        if (this.isMovable(index)) {
            const tile = this.boardElement.children[index];
            tile.classList.add('moving');
            
            [this.board[index], this.board[this.emptyIndex]] = 
            [this.board[this.emptyIndex], this.board[index]];
            
            this.emptyIndex = index;
            this.moves++;
            
            setTimeout(() => {
                this.render();
                this.checkWin();
            }, 300);
        }
    }

    checkWin() {
        const isWin = this.board.every((num, index) => num === index);
        if (isWin) {
            setTimeout(() => {
                alert(`Congratulations! You solved the puzzle in ${this.moves} moves!`);
                this.shuffle();
                this.moves = 0;
                this.render();
            }, 300);
        }
    }

    addEventListeners() {
        this.boardElement.addEventListener('click', (e) => {
            const tile = e.target.closest('.tile');
            if (tile && !tile.classList.contains('empty')) {
                const index = parseInt(tile.dataset.index);
                this.moveTile(index);
            }
        });

        this.shuffleButton.addEventListener('click', () => {
            this.shuffle();
            this.moves = 0;
            this.render();
        });
    }
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new PuzzleGame();
});