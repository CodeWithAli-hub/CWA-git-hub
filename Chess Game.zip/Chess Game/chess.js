class ChessGame {
    constructor() {
        this.board = this.createBoard();
        this.currentPlayer = 'white';
        this.selectedPiece = null;
        this.validMoves = [];
        this.gameStatus = 'active'; // active, check, checkmate, stalemate
        this.capturedPieces = {
            white: [],
            black: []
        };
        this.moveHistory = [];
        this.setupBoard();
        this.renderBoard();
        this.setupEventListeners();
    }

    // Create the initial board structure
    createBoard() {
        const board = [];
        for (let row = 0; row < 8; row++) {
            board[row] = [];
            for (let col = 0; col < 8; col++) {
                board[row][col] = null;
            }
        }
        return board;
    }

    // Set up the initial piece positions
    setupBoard() {
        // Set up pawns
        for (let col = 0; col < 8; col++) {
            this.board[1][col] = { type: 'pawn', color: 'black', hasMoved: false };
            this.board[6][col] = { type: 'pawn', color: 'white', hasMoved: false };
        }

        // Set up rooks
        this.board[0][0] = { type: 'rook', color: 'black', hasMoved: false };
        this.board[0][7] = { type: 'rook', color: 'black', hasMoved: false };
        this.board[7][0] = { type: 'rook', color: 'white', hasMoved: false };
        this.board[7][7] = { type: 'rook', color: 'white', hasMoved: false };

        // Set up knights
        this.board[0][1] = { type: 'knight', color: 'black' };
        this.board[0][6] = { type: 'knight', color: 'black' };
        this.board[7][1] = { type: 'knight', color: 'white' };
        this.board[7][6] = { type: 'knight', color: 'white' };

        // Set up bishops
        this.board[0][2] = { type: 'bishop', color: 'black' };
        this.board[0][5] = { type: 'bishop', color: 'black' };
        this.board[7][2] = { type: 'bishop', color: 'white' };
        this.board[7][5] = { type: 'bishop', color: 'white' };

        // Set up queens
        this.board[0][3] = { type: 'queen', color: 'black' };
        this.board[7][3] = { type: 'queen', color: 'white' };

        // Set up kings
        this.board[0][4] = { type: 'king', color: 'black', hasMoved: false };
        this.board[7][4] = { type: 'king', color: 'white', hasMoved: false };
    }

    // Render the board on the page
    renderBoard() {
        const chessboard = document.getElementById('chessboard');
        chessboard.innerHTML = '';

        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const square = document.createElement('div');
                square.className = `square ${(row + col) % 2 === 0 ? 'white' : 'black'}`;
                square.dataset.row = row;
                square.dataset.col = col;

                const piece = this.board[row][col];
                if (piece) {
                    square.innerHTML = this.getPieceSymbol(piece);
                }

                chessboard.appendChild(square);
            }
        }

        // Update status display
        document.getElementById('status').textContent = 
            this.gameStatus === 'active' ? 
            `${this.currentPlayer.charAt(0).toUpperCase() + this.currentPlayer.slice(1)}'s turn` : 
            `Game over: ${this.gameStatus}`;

        // Update captured pieces
        this.renderCapturedPieces();
    }

    // Get Unicode symbol for chess pieces
    getPieceSymbol(piece) {
        const symbols = {
            'white': {
                'king': '♔',
                'queen': '♕',
                'rook': '♖',
                'bishop': '♗',
                'knight': '♘',
                'pawn': '♙'
            },
            'black': {
                'king': '♚',
                'queen': '♛',
                'rook': '♜',
                'bishop': '♝',
                'knight': '♞',
                'pawn': '♟'
            }
        };
        return symbols[piece.color][piece.type];
    }

    // Set up event listeners for the board
    setupEventListeners() {
        const chessboard = document.getElementById('chessboard');
        chessboard.addEventListener('click', (e) => {
            if (this.gameStatus !== 'active') return;
            
            const square = e.target.closest('.square');
            if (!square) return;

            const row = parseInt(square.dataset.row);
            const col = parseInt(square.dataset.col);

            this.handleSquareClick(row, col);
        });

        // Reset button
        document.getElementById('reset-btn').addEventListener('click', () => {
            this.resetGame();
        });
    }

    // Handle click on a square
    handleSquareClick(row, col) {
        const piece = this.board[row][col];

        // If no piece is selected and clicked on a piece of current player's color
        if (!this.selectedPiece && piece && piece.color === this.currentPlayer) {
            this.selectedPiece = { row, col, piece };
            this.validMoves = this.getValidMoves(row, col, piece);
            this.highlightSquare(row, col, true);
            this.highlightValidMoves(this.validMoves, true);
        } 
        // If a piece is already selected
        else if (this.selectedPiece) {
            // If clicking on the same piece, deselect it
            if (row === this.selectedPiece.row && col === this.selectedPiece.col) {
                this.deselectPiece();
            } 
            // If clicking on another piece of the same color, select that piece instead
            else if (piece && piece.color === this.currentPlayer) {
                this.deselectPiece();
                this.selectedPiece = { row, col, piece };
                this.validMoves = this.getValidMoves(row, col, piece);
                this.highlightSquare(row, col, true);
                this.highlightValidMoves(this.validMoves, true);
            } 
            // If clicking on a valid move square
            else if (this.isValidMove(row, col)) {
                this.movePiece(this.selectedPiece.row, this.selectedPiece.col, row, col);
                this.deselectPiece();
                this.switchPlayer();
                this.checkGameStatus();
            } 
            // If clicking on an invalid square, deselect the piece
            else {
                this.deselectPiece();
            }
        }
    }

    // Deselect the currently selected piece
    deselectPiece() {
        if (this.selectedPiece) {
            this.highlightSquare(this.selectedPiece.row, this.selectedPiece.col, false);
            this.highlightValidMoves(this.validMoves, false);
            this.selectedPiece = null;
            this.validMoves = [];
        }
    }

    // Highlight or unhighlight a square
    highlightSquare(row, col, highlight) {
        const squares = document.querySelectorAll('.square');
        const index = row * 8 + col;
        if (highlight) {
            squares[index].classList.add('selected');
        } else {
            squares[index].classList.remove('selected');
        }
    }

    // Highlight or unhighlight valid move squares
    highlightValidMoves(moves, highlight) {
        const squares = document.querySelectorAll('.square');
        moves.forEach(move => {
            const index = move.row * 8 + move.col;
            if (highlight) {
                squares[index].classList.add('valid-move');
            } else {
                squares[index].classList.remove('valid-move');
            }
        });
    }

    // Check if a move is in the valid moves list
    isValidMove(row, col) {
        return this.validMoves.some(move => move.row === row && move.col === col);
    }

    // Move a piece from one square to another
    movePiece(fromRow, fromCol, toRow, toCol) {
        const piece = this.board[fromRow][fromCol];
        const targetPiece = this.board[toRow][toCol];

        // Record move in history
        this.moveHistory.push({
            piece: { ...piece },
            from: { row: fromRow, col: fromCol },
            to: { row: toRow, col: toCol },
            captured: targetPiece ? { ...targetPiece } : null
        });

        // Handle captures
        if (targetPiece) {
            this.capturedPieces[targetPiece.color].push(targetPiece);
        }

        // Update piece position
        this.board[toRow][toCol] = piece;
        this.board[fromRow][fromCol] = null;

        // Mark piece as moved (for pawns, kings, rooks)
        if (piece.hasMoved !== undefined) {
            piece.hasMoved = true;
        }

        // Handle pawn promotion
        if (piece.type === 'pawn' && (toRow === 0 || toRow === 7)) {
            this.promotePawn(toRow, toCol);
        }

        // Handle castling
        if (piece.type === 'king' && Math.abs(fromCol - toCol) === 2) {
            this.handleCastling(fromRow, fromCol, toRow, toCol);
        }

        // Render the updated board
        this.renderBoard();
    }

    // Handle castling move
    handleCastling(fromRow, fromCol, toRow, toCol) {
        // Kingside castling
        if (toCol > fromCol) {
            // Move the rook
            const rook = this.board[fromRow][7];
            this.board[fromRow][5] = rook;
            this.board[fromRow][7] = null;
        } 
        // Queenside castling
        else {
            // Move the rook
            const rook = this.board[fromRow][0];
            this.board[fromRow][3] = rook;
            this.board[fromRow][0] = null;
        }
    }

    // Promote a pawn to a queen (simplified - always promotes to queen)
    promotePawn(row, col) {
        this.board[row][col] = { type: 'queen', color: this.board[row][col].color };
    }

    // Switch the current player
    switchPlayer() {
        this.currentPlayer = this.currentPlayer === 'white' ? 'black' : 'white';
    }

    // Check if the game is over (checkmate or stalemate)
    checkGameStatus() {
        const kingPosition = this.findKing(this.currentPlayer);
        const isInCheck = this.isSquareUnderAttack(kingPosition.row, kingPosition.col, this.currentPlayer);
        
        // Check if the current player has any valid moves
        const hasValidMoves = this.hasAnyValidMoves(this.currentPlayer);
        
        if (isInCheck && !hasValidMoves) {
            this.gameStatus = 'checkmate';
            document.getElementById('status').textContent = 
                `Checkmate! ${this.currentPlayer === 'white' ? 'Black' : 'White'} wins!`;
        } else if (!isInCheck && !hasValidMoves) {
            this.gameStatus = 'stalemate';
            document.getElementById('status').textContent = 'Stalemate! The game is a draw.';
        } else if (isInCheck) {
            this.gameStatus = 'check';
            document.getElementById('status').textContent = 
                `${this.currentPlayer.charAt(0).toUpperCase() + this.currentPlayer.slice(1)} is in check!`;
        } else {
            this.gameStatus = 'active';
        }
    }

    // Check if a player has any valid moves
    hasAnyValidMoves(color) {
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const piece = this.board[row][col];
                if (piece && piece.color === color) {
                    const moves = this.getValidMoves(row, col, piece);
                    if (moves.length > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Find the king of a specific color
    findKing(color) {
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const piece = this.board[row][col];
                if (piece && piece.type === 'king' && piece.color === color) {
                    return { row, col };
                }
            }
        }
        return null;
    }

    // Check if a square is under attack by the opponent
    isSquareUnderAttack(row, col, color) {
        const opponentColor = color === 'white' ? 'black' : 'white';
        
        for (let r = 0; r < 8; r++) {
            for (let c = 0; c < 8; c++) {
                const piece = this.board[r][c];
                if (piece && piece.color === opponentColor) {
                    const moves = this.getPieceMoves(r, c, piece, true);
                    if (moves.some(move => move.row === row && move.col === col)) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }

    // Get all valid moves for a piece
    getValidMoves(row, col, piece) {
        const potentialMoves = this.getPieceMoves(row, col, piece, false);
        
        // Filter out moves that would put or leave the king in check
        return potentialMoves.filter(move => {
            // Simulate the move
            const originalPiece = this.board[move.row][move.col];
            this.board[move.row][move.col] = piece;
            this.board[row][col] = null;
            
            // Check if the king is in check after the move
            const kingPosition = piece.type === 'king' ? 
                { row: move.row, col: move.col } : 
                this.findKing(piece.color);
            
            const isInCheck = this.isSquareUnderAttack(
                kingPosition.row, 
                kingPosition.col, 
                piece.color
            );
            
            // Undo the move
            this.board[row][col] = piece;
            this.board[move.row][move.col] = originalPiece;
            
            // Return true if the move doesn't put the king in check
            return !isInCheck;
        });
    }

    // Get all possible moves for a piece without checking for check
    getPieceMoves(row, col, piece, ignoreKing = false) {
        switch (piece.type) {
            case 'pawn':
                return this.getPawnMoves(row, col, piece);
            case 'rook':
                return this.getRookMoves(row, col, piece);
            case 'knight':
                return this.getKnightMoves(row, col, piece);
            case 'bishop':
                return this.getBishopMoves(row, col, piece);
            case 'queen':
                return this.getQueenMoves(row, col, piece);
            case 'king':
                return this.getKingMoves(row, col, piece, ignoreKing);
            default:
                return [];
        }
    }

    // Get all possible moves for a pawn
    getPawnMoves(row, col, piece) {
        const moves = [];
        const direction = piece.color === 'white' ? -1 : 1;
        
        // Forward move
        if (this.isInBounds(row + direction, col) && !this.board[row + direction][col]) {
            moves.push({ row: row + direction, col });
            
            // Double move from starting position
            if (!piece.hasMoved && 
                this.isInBounds(row + 2 * direction, col) && 
                !this.board[row + 2 * direction][col] && 
                !this.board[row + direction][col]) {
                moves.push({ row: row + 2 * direction, col });
            }
        }
        
        // Capture moves
        for (let colOffset of [-1, 1]) {
            const newCol = col + colOffset;
            if (this.isInBounds(row + direction, newCol)) {
                const targetPiece = this.board[row + direction][newCol];
                if (targetPiece && targetPiece.color !== piece.color) {
                    moves.push({ row: row + direction, col: newCol });
                }
            }
        }
        
        return moves;
    }

    // Get all possible moves for a rook
    getRookMoves(row, col, piece) {
        return this.getSlidingMoves(row, col, piece, [
            { rowDir: -1, colDir: 0 }, // Up
            { rowDir: 1, colDir: 0 },  // Down
            { rowDir: 0, colDir: -1 }, // Left
            { rowDir: 0, colDir: 1 }   // Right
        ]);
    }

    // Get all possible moves for a bishop
    getBishopMoves(row, col, piece) {
        return this.getSlidingMoves(row, col, piece, [
            { rowDir: -1, colDir: -1 }, // Up-left
            { rowDir: -1, colDir: 1 },  // Up-right
            { rowDir: 1, colDir: -1 },  // Down-left
            { rowDir: 1, colDir: 1 }    // Down-right
        ]);
    }

    // Get all possible moves for a queen
    getQueenMoves(row, col, piece) {
        return [
            ...this.getRookMoves(row, col, piece),
            ...this.getBishopMoves(row, col, piece)
        ];
    }

    // Get all possible moves for a knight
    getKnightMoves(row, col, piece) {
        const moves = [];
        const offsets = [
            { row: -2, col: -1 }, { row: -2, col: 1 },
            { row: -1, col: -2 }, { row: -1, col: 2 },
            { row: 1, col: -2 }, { row: 1, col: 2 },
            { row: 2, col: -1 }, { row: 2, col: 1 }
        ];
        
        for (const offset of offsets) {
            const newRow = row + offset.row;
            const newCol = col + offset.col;
            
            if (this.isInBounds(newRow, newCol)) {
                const targetPiece = this.board[newRow][newCol];
                if (!targetPiece || targetPiece.color !== piece.color) {
                    moves.push({ row: newRow, col: newCol });
                }
            }
        }
        
        return moves;
    }

    // Get all possible moves for a king
    getKingMoves(row, col, piece, ignoreKing = false) {
        const moves = [];
        
        // Regular king moves
        for (let rowOffset = -1; rowOffset <= 1; rowOffset++) {
            for (let colOffset = -1; colOffset <= 1; colOffset++) {
                if (rowOffset === 0 && colOffset === 0) continue;
                
                const newRow = row + rowOffset;
                const newCol = col + colOffset;
                
                if (this.isInBounds(newRow, newCol)) {
                    const targetPiece = this.board[newRow][newCol];
                    if (!targetPiece || targetPiece.color !== piece.color) {
                        moves.push({ row: newRow, col: newCol });
                    }
                }
            }
        }
        
        // Castling moves (only if not checking for attacks)
        if (!ignoreKing && !piece.hasMoved && this.gameStatus !== 'check') {
            // Kingside castling
            if (!this.board[row][5] && !this.board[row][6]) {
                const rook = this.board[row][7];
                if (rook && rook.type === 'rook' && rook.color === piece.color && !rook.hasMoved) {
                    // Check if the king's path is not under attack
                    if (!this.isSquareUnderAttack(row, col, piece.color) && 
                        !this.isSquareUnderAttack(row, col + 1, piece.color) && 
                        !this.isSquareUnderAttack(row, col + 2, piece.color)) {
                        moves.push({ row, col: col + 2 });
                    }
                }
            }
            
            // Queenside castling
            if (!this.board[row][3] && !this.board[row][2] && !this.board[row][1]) {
                const rook = this.board[row][0];
                if (rook && rook.type === 'rook' && rook.color === piece.color && !rook.hasMoved) {
                    // Check if the king's path is not under attack
                    if (!this.isSquareUnderAttack(row, col, piece.color) && 
                        !this.isSquareUnderAttack(row, col - 1, piece.color) && 
                        !this.isSquareUnderAttack(row, col - 2, piece.color)) {
                        moves.push({ row, col: col - 2 });
                    }
                }
            }
        }
        
        return moves;
    }

    // Get moves for sliding pieces (rook, bishop, queen)
    getSlidingMoves(row, col, piece, directions) {
        const moves = [];
        
        for (const dir of directions) {
            let newRow = row + dir.rowDir;
            let newCol = col + dir.colDir;
            
            while (this.isInBounds(newRow, newCol)) {
                const targetPiece = this.board[newRow][newCol];
                
                if (!targetPiece) {
                    // Empty square, can move here
                    moves.push({ row: newRow, col: newCol });
                } else if (targetPiece.color !== piece.color) {
                    // Opponent's piece, can capture and then stop
                    moves.push({ row: newRow, col: newCol });
                    break;
                } else {
                    // Own piece, can't move here or beyond
                    break;
                }
                
                newRow += dir.rowDir;
                newCol += dir.colDir;
            }
        }
        
        return moves;
    }

    // Check if coordinates are within the board
    isInBounds(row, col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }

    // Render captured pieces
    renderCapturedPieces() {
        const whiteCaptured = document.getElementById('white-captured');
        const blackCaptured = document.getElementById('black-captured');
        
        whiteCaptured.innerHTML = '';
        blackCaptured.innerHTML = '';
        
        this.capturedPieces.black.forEach(piece => {
            const pieceElement = document.createElement('span');
            pieceElement.textContent = this.getPieceSymbol(piece);
            whiteCaptured.appendChild(pieceElement);
        });
        
        this.capturedPieces.white.forEach(piece => {
            const pieceElement = document.createElement('span');
            pieceElement.textContent = this.getPieceSymbol(piece);
            blackCaptured.appendChild(pieceElement);
        });
    }

    // Reset the game
    resetGame() {
        this.board = this.createBoard();
        this.currentPlayer = 'white';
        this.selectedPiece = null;
        this.validMoves = [];
        this.gameStatus = 'active';
        this.capturedPieces = {
            white: [],
            black: []
        };
        this.moveHistory = [];
        this.setupBoard();
        this.renderBoard();
    }
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new ChessGame();
});